# -*- coding: utf-8 -*-
"""
Created on Mon Jun 27 17:34:22 2022

@author: 123
"""

#########NYU---->UM

import torch
import numpy as np
from sklearn.model_selection import train_test_split
import scipy.sparse as sp
import scipy.io
import scipy.linalg
import torch.nn as nn
import torch
import torch.nn.init as init
import scipy.sparse as sp
import torch.nn.functional as F
import torch.optim as optim
from sklearn.metrics import accuracy_score, recall_score, f1_score, roc_auc_score, precision_score
import pickle
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix,roc_curve,auc
from sklearn.manifold import TSNE
from torch.optim import lr_scheduler,Adam
import itertools
torch.manual_seed(987)
torch.cuda.manual_seed(985)#
def Mydataset(mydata,DEVICE):

    D1_Label = mydata['Domain_Label'].T
    D1_Label[D1_Label>1]=0
    graph_labels=D1_Label.T
       
    D1_adj = mydata['Domain_Data'].T
    a=D1_adj
    apc = []
    for i in range(len(a)):
        apc.append(a[i])
    unique_indicator = range(len(a))
    train_index, test_index = train_test_split(unique_indicator,train_size=0.5,random_state=186)
    apc_arr = np.array(apc)
    ad_tr = apc_arr[train_index]
    ad_te = apc_arr[test_index]
    con = np.concatenate([ad_tr,ad_te],axis=0)
    ad_tr_abs = abs(con)
    adj_tr = scipy.linalg.block_diag(*ad_tr_abs)
    adj_tr_csr = sp.csr_matrix(adj_tr)
    node_fea_tr = np.concatenate(con)   
    adj_tr = normalization(adj_tr_csr).to(DEVICE)
    fea_tr = torch.from_numpy(node_fea_tr).type(torch.float32).to(DEVICE)
    lab = np.concatenate([graph_labels[0][train_index],graph_labels[0][test_index]],axis=0)
    lab_tr =torch.from_numpy(lab).type(torch.float32).to(DEVICE)
    return adj_tr, fea_tr, lab_tr
    
    

def tensor_from_numpy(x, device):  #
       return torch.from_numpy(x).to(device)


def normalization(adjacency):

    adjacency += sp.eye(adjacency.shape[0])
    degree = np.array(adjacency.sum(1))
    d_hat = sp.diags(np.power(degree, -0.5).flatten())
    L = d_hat.dot(adjacency).dot(d_hat).tocoo()
    indices = torch.from_numpy(np.asarray([L.row, L.col])).long()
    values = torch.from_numpy(L.data.astype(np.float32))
    tensor_adjacency = torch.sparse.FloatTensor(indices, values, L.shape)
 
    return tensor_adjacency




class GraphConvolution(nn.Module):
    def __init__(self, input_dim, output_dim, use_bias=True):

        super(GraphConvolution, self).__init__()
        self.input_dim = input_dim
        self.output_dim = output_dim
        self.use_bias = use_bias

        self.weight = nn.Parameter(torch.Tensor(input_dim, output_dim))
        if self.use_bias:
            self.bias = nn.Parameter(torch.Tensor(output_dim))
        else:
            self.register_parameter('bias', None)
        self.reset_parameters()

    def reset_parameters(self):
        init.kaiming_uniform_(self.weight)
        if self.use_bias:
            init.zeros_(self.bias)
        pass

    def forward(self, adjacency, input_feature):

        support = torch.mm(input_feature, self.weight)
        output = torch.sparse.mm(adjacency, support)  # L(XW)  (N,output_dim=hidden_dim)
        if self.use_bias:
            output += self.bias
        return output




class Att(nn.Module):
    def __init__(self,hidden,out_dim):
        super().__init__()
        self.linear=nn.Linear(hidden,hidden)
        self.linear2 = nn.Linear(hidden,out_dim)
        self.sigmoid =nn.Sigmoid()
        self.tanh = nn.Tanh()
    def forward(self,x):

        x=self.linear(x)
        x=self.linear2(x)
        output = self.sigmoid(x)

        return output
class GNN(nn.Module):
    def __init__(self, input_dim, hidden_dim):
   
        super(GNN, self).__init__()
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.gcn1 = GraphConvolution(input_dim, hidden_dim)
        self.gcn2 = GraphConvolution(hidden_dim, hidden_dim)
        self.att = Att(116,116)

        self.batn = nn.BatchNorm1d(116)
    def forward(self, adjacency, input_feature):
        gcn1 = F.relu(self.gcn1(adjacency, input_feature))  # (N,hidden_dim)
        gcn2 = F.relu(self.gcn2(adjacency, gcn1))  # (N,hidden_dim)
        gcn_feature = gcn2.reshape(-1,116,32)

        x =  torch.amax(gcn_feature, 2)
        att_out= self.att(x)
        att_out = att_out.reshape(-1,116,1)#
        out = self.batn(gcn_feature*att_out+gcn_feature)
        readout=torch.mean(out,-1)
        readout2=torch.amax(out,-1)

        readout = torch.cat((readout, readout2), dim=1)
        #print(readout.size())
        return readout,att_out
    
def predict(D2adj_tr, D2fea_tr):
    encoded_output,att = encoder(D2adj_tr, D2fea_tr)
    logits = cls_model(encoded_output)
    return logits



def test(D2adj_tr, D2fea_tr, D2lab_tr ):
    for model in models:
        model.eval()
    logits = predict(D2adj_tr, D2fea_tr )
    #preds = logits.argmax(dim=1)
    accuracy  = torch.eq(logits.max(1)[1], D2lab_tr).float().mean()
    return accuracy    




def CORAL(source, target, **kwargs):
    d = source.data.shape[1]
    ns, nt = source.data.shape[0], target.data.shape[0]
    # source covariance
    xm = torch.mean(source, 0, keepdim=True) - source
    xc = xm.t() @ xm / (ns - 1)

    # target covariance
    xmt = torch.mean(target, 0, keepdim=True) - target
    xct = xmt.t() @ xmt / (nt - 1)

    # frobenius norm between source and target
    loss = torch.mul((xc - xct), (xc - xct))
    loss = torch.sum(loss) / (4*d*d)
    return loss





def calculate_metric(gt, pred): 
        pred[pred>0.5]=1
        pred[pred<1]=0
        confusion = confusion_matrix(gt,pred)
        TP = confusion[1, 1]
        TN = confusion[0, 0]
        FP = confusion[0, 1]
        FN = confusion[1, 0]
        Accuracy=(TP+TN)/float(TP+TN+FP+FN)
        Sensitivity=TP / float(TP+FN)
        Specificity=TN / float(TN+FP)
        
        return Accuracy,Sensitivity,Specificity
def test_(D2adj_tr, D2fea_tr, D2lab_tr ):
    for model in models:
        model.eval()
    logits = predict(D2adj_tr, D2fea_tr )
    preds = logits.argmax(dim=1)
    #accuracy  = torch.eq(logits.max(1)[1], D2lab_tr).float().mean()
    Accuracy,Sensitivity,Specificity = calculate_metric(D2lab_tr.cpu().numpy(),preds.cpu().numpy())
    logits
    return Accuracy,Sensitivity,Specificity,logits


device =  "cuda"#"cuda" if torch.cuda.is_available() else "cpu"

mydata=scipy.io.loadmat('data/NYU/D1.mat')
D1adj_tr, D1fea_tr, D1lab_tr=Mydataset(mydata,device)
mydata2=scipy.io.loadmat('data/UM/D2.mat')
D2adj_tr, D2fea_tr, D2lab_tr=Mydataset(mydata2,device)
INPUT_DIM = 116
NUM_CLASSES = 2
HIDDEN_DIM = 32  # @param {type: "integer"}
encoder_dim=116*2

encoder = GNN(INPUT_DIM, HIDDEN_DIM).to(device)
cls_model = nn.Sequential(
    nn.Linear(encoder_dim, 64),
    nn.Dropout(0.4),
    nn.Linear(64, 2),
).to(device)


models = [encoder, cls_model]

criterion = nn.CrossEntropyLoss()#.to(DEVICE)
criterion_mae = nn.L1Loss()

loss_func = nn.CrossEntropyLoss().to(device)
params = itertools.chain(*[model.parameters() for model in models])
optimizer = torch.optim.Adam(params, lr=3e-3)
epochs = 150
def train(epoch):
    for model in models:
        model.train()    

    
    optimizer.zero_grad()
    
    global rate

    p = float(1 + epoch * 1) / (epochs * 1)
    rate = 2. / (1. + np.exp(-10 * p)) - 1
    encoded_source,att_s = encoder(D1adj_tr, D1fea_tr)
    encoded_target,att_t = encoder(D2adj_tr, D2fea_tr)
    source_logits = cls_model(encoded_source)
    

    cls_loss  = criterion(source_logits, D1lab_tr.long())  
    for model in models:
        for name, param in model.named_parameters():
            if "weight" in name:
                cls_loss = cls_loss + param.mean() * 3e-3
    

    domain_loss= CORAL(encoded_source,encoded_target)

    att_loss = criterion_mae(att_s[:att_t.shape[0],:att_t.shape[1]],att_t)
    if epoch>50 and epoch<150:
       loss = torch.log(cls_loss + 1e-9)+ 0.5* att_loss.detach() +  0.5* domain_loss
    else:
        loss = att_loss+domain_loss
    
    
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()
    
    return  
   
best_source_acc = 0.0
best_target_acc = 0.0
best_epoch = 0.0
accuracy_s,sensitivity_s,specificity_s,accuracy_t,sensitivity_t,specificity_t,auc_s,auc_t = [],[],[],[],[],[],[],[]
for epoch in range(1, epochs):
    train(epoch)

    Accuracy_s,Sensitivity_s,Specificity_s,logits_s = test_(D1adj_tr, D1fea_tr,D1lab_tr)
    Accuracy_t,Sensitivity_t,Specificity_t,logits_t = test_(D2adj_tr, D2fea_tr, D2lab_tr)
    accuracy_s.append(Accuracy_s)
    sensitivity_s.append(Sensitivity_s)
    specificity_s.append(Specificity_s)
    accuracy_t.append(Accuracy_t)
    sensitivity_t.append(Sensitivity_t)
    specificity_t.append(Specificity_t)
    Auc_t = roc_auc_score(D2lab_tr.detach().cpu().numpy(), logits_t[:, 1].detach().cpu().numpy())
    Auc_s = roc_auc_score(D1lab_tr.detach().cpu().numpy(), logits_s[:, 1].detach().cpu().numpy())
    auc_s.append(Auc_s)
    auc_t.append(Auc_t)
   
    print("Epoch: {}, Acc_s: {},  Acc_t: {},auc_t: {}"\
           .format(epoch,Accuracy_s,Accuracy_t, Auc_t))
    if Accuracy_t > best_target_acc:
        best_target_acc = Accuracy_t
        best_source_acc = Accuracy_s
        Sensitivity_best_source = Sensitivity_s
        Specificity_best_source = Specificity_s
        Sensitivity_best_target = Sensitivity_t
        Specificity_best_target = Specificity_t
        auc_best_target=Auc_t
        best_epoch = epoch
        torch.save(encoder, 'model/encode.pt')

print("=============================================================")

line = "{} - Epoch: {},btacc: {},btSen: {},btSpe: {},btauc: {}"\
    .format(id, best_epoch,  best_target_acc,Sensitivity_best_target,Specificity_best_target,auc_best_target)
print(line)  


